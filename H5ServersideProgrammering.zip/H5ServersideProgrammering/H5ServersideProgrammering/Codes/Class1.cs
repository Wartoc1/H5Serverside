﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace H5ServersideProgrammering.Codes
{
    public class Class1
    {
        public string GetText()
        {
            return "Hello Niels";
        }

        public string GetText2()
        {
            return "Hello H5";
        }
    }
}
