﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using H5ServersideProgrammering.Models.EntityFrameworkCore;
using Microsoft.AspNetCore.DataProtection;
using H5ServersideProgrammering.Codes;

namespace H5ServersideProgrammering.Controllers
{
    public class ToDoesController : Controller
    {
        private readonly TestContext _context;
        private readonly IDataProtector _dataProtector;
        private readonly CrytpExample _crytpExample;

        public ToDoesController(TestContext context, IDataProtectionProvider dataProtection, CrytpExample crytpExample)
        {
            _context = context;
            _crytpExample = crytpExample;
            _dataProtector = dataProtection.CreateProtector("H5ServersideProgrammering.MyToDoesController.NielsOlesen");
        }

        // GET: ToDoes
        public async Task<IActionResult> Index()
        {
            var userIdentityName = User.Identity.Name;

            var rows = await _context.ToDos.Where(s => s.User == userIdentityName).ToListAsync();
            bool matchFound = rows.Count > 0;

            if (matchFound)
            {
                foreach (H5ServersideProgrammering.Models.EntityFrameworkCore.ToDo row in rows)
                {
                    string encryptedText = row.Description;
                    row.Description = _crytpExample.Decrypt(encryptedText, _dataProtector);
                }
                return View(rows);
            }
            else
            {
                return View(new List<H5ServersideProgrammering.Models.EntityFrameworkCore.ToDo>());
            }

        }

        // GET: ToDoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toDo = await _context.ToDos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toDo == null)
            {
                return NotFound();
            }

            return View(toDo);
        }

        // GET: ToDoes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ToDoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Description,User")] ToDo toDo)
        {
            if (ModelState.IsValid)
            {
                string description = toDo.Description;
                toDo.Description = _crytpExample.Encrypt(description, _dataProtector);

                _context.Add(toDo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(toDo);
        }

        // GET: ToDoes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toDo = await _context.ToDos.FindAsync(id);
            if (toDo == null)
            {
                return NotFound();
            }
            return View(toDo);
        }

        // POST: ToDoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,User")] ToDo toDo)
        {
            if (id != toDo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(toDo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ToDoExists(toDo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(toDo);
        }

        // GET: ToDoes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toDo = await _context.ToDos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toDo == null)
            {
                return NotFound();
            }

            return View(toDo);
        }

        // POST: ToDoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var toDo = await _context.ToDos.FindAsync(id);
            _context.ToDos.Remove(toDo);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ToDoExists(int id)
        {
            return _context.ToDos.Any(e => e.Id == id);
        }
    }
}
