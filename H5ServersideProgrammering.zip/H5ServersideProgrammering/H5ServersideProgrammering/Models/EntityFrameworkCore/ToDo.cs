﻿using System;
using System.Collections.Generic;

#nullable disable

namespace H5ServersideProgrammering.Models.EntityFrameworkCore
{
    public partial class ToDo
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string User { get; set; }
    }
}
